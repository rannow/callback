/**
 * Example of Toolkit Applet
 */

package ToolkitAppletExample;

import sim.toolkit.*;
import sim.access.*;
import javacard.framework.*;

public class MyToolkitApplet extends javacard.framework.Applet implements ToolkitInterface, ToolkitConstants 
{
    // BIP Constants
    private static final byte TAG_DATA_DESTINATION_ADDRESS           = (byte) 0x3E;
  
    // Bearer variables
    // --> GPRS case...
    
    // The APN is a reference to a GGSN: myoperator.mycountry
    // This value is coded in a special way: LVLV...
    // For example myoperator.mycountry should be coded as follow
    private static byte[] myAPN = {(byte)0x0A,(byte)'m',(byte)'y',(byte)'o',(byte)'p',(byte)'e',(byte)'r',(byte)'a',(byte)'t',(byte)'o',
                             (byte)'r',(byte)0x09,(byte)'m',(byte)'y',(byte)'c',(byte)'o',(byte)'u',(byte)'n',(byte)'t',
                             (byte)'r',(byte)'y'};
    
    //GPRS = 0x02
    private static final byte BEARER_TYPE_GPRS                       = (byte) 0x02; 

    // The service precedence class indicates the relative priority of maintaining the service
    //Precedence Class n�1 => High priority.
    private static final byte BEARER_PARAMETER_PRECEDENCE_CLASS1     = (byte) 0x01;
    
    // The delay parameter defines the end-to-end transfer delay incurred in the transmission of the SDUs through 
    // the GPRS network
    //Delay Class n�1 => Predictive 
    private static final byte BEARER_PARAMETER_DELAY_CLASS1          = (byte) 0x01;

    // The reliability parameter indicates the transmission characteristics that are required by an application. 
    // The reliability class defines the probability of loss of, duplication of, 
    // mis sequencing of or corruption of SDUs
    private static final byte BEARER_PARAMETER_RELIABILITY_CLASS1    = (byte) 0x01;

    // The peak throughput class specifies the maximum rate at which data is expected to be transferred accross
    // the network for an individual PDP context.
    //Peak throughput in octets per second up to 1000 (8kbits/s)
    private static final byte BEARER_PARAMETER_PEAK_THROUGHPUT_CLASS1= (byte) 0x01;
    
    // The Mean throughput class specifies the average rate at which data is expected to be transferred 
    // accross the GPRS network during the remaining lifetime of an activated Packet Data Protocol (PDP) context.
    //Mean throughput in octets per hour 100 (~0.22bits/s)
    private static final byte BEARER_PARAMETER_MEAN_THROUGHPUT_CLASS1    = (byte) 0x01;

    // PDP Type --> IP
    private static final byte BEARER_PARAMETER_PDP_IP                    = (byte) 0x02;

    // Define parameters necessary to launch a PDP context
    private static byte[] BearerParameters=    {(byte) BEARER_TYPE_GPRS, (byte) BEARER_PARAMETER_PRECEDENCE_CLASS1,
        (byte) BEARER_PARAMETER_DELAY_CLASS1, (byte) BEARER_PARAMETER_RELIABILITY_CLASS1,
        (byte) BEARER_PARAMETER_PEAK_THROUGHPUT_CLASS1, (byte) BEARER_PARAMETER_MEAN_THROUGHPUT_CLASS1,
        (byte) BEARER_PARAMETER_PDP_IP };

    // Type of Address IPV4=21,
    private static final byte TYPE_OF_ADDRESS_IPV4      = (byte) 0x21;
    // SIM/ME interface transport level UDP=01
    private static final byte TRANSPORT_PROTOCOL_TYPE   = (byte) 0x01;

    // --> ... end GPRS case

    public static final byte MY_INSTRUCTION         = (byte)0x46;
    public static final byte SERVER_OPERATION       = (byte)0x0F;
    public static final byte CMD_QUALIFIER          = (byte)0x80;
    public static final byte EXIT_REQUESTED_BY_USER = (byte)0x10;

    private byte[] menuEntry =    {(byte)'0',(byte)'3',(byte)'.',(byte)'1',(byte)'9',(byte)' ',(byte)'A',(byte)'p',(byte)'p',(byte)'l',(byte)'e',(byte)'t'};
    
    private byte[] menuTitle=     {(byte)'M',(byte)'y',(byte)'M',(byte)'e',(byte)'n' ,(byte)'u'};
    private byte[] item1 =        {(byte)'I',(byte)'T',(byte)'E',(byte)'M',(byte)'1' };
    private byte[] item2 =        {(byte)'I',(byte)'T',(byte)'E',(byte)'M',(byte)'2' };
    private byte[] item3 =        {(byte)'I',(byte)'T',(byte)'E',(byte)'M',(byte)'3' };
    private byte[] item4 =        {(byte)'I',(byte)'T',(byte)'E',(byte)'M',(byte)'4' };
    private Object[] ItemList =   { item1, item2, item3, item4 };
    private byte[] textDText =    {(byte)'H',(byte)'e',(byte)'l',(byte)'l',(byte)'o',(byte)' ',
      (byte)'w',(byte)'o',(byte)'r',(byte)'l',(byte)'d',(byte)'2'};
    private byte[] textGInput =    {(byte)'Y',(byte)'o',(byte)'u',(byte)'r',(byte)' ',(byte)'n',
      (byte)'a',(byte)'m',(byte)'e',(byte)'?'};

    private byte[]  baGSMAID =    {(byte)0xA0, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x09, (byte)0x00, (byte)0x01};
    private ToolkitRegistry reg;
    private SIMView gsmFile;
    private byte buffer[] = new byte[10];
    private byte itemId;
    private byte result;


    // Allocate 500 bytes for the reception buffer
    private static final short BUFFER_SIZE = (short)0x01F4;    
    // TLVs overhead in the Terminal Response in case of Receice Data: 
    //      Command details size: 5 bytes
    //      Device identities size : 4 bytes
    //      Result size : 3 bytes (in success case)
    //      Channel data length size : 3 bytes
    //      Channel data TL size : 3 bytes
    private static final short MAX_TLV_OVERHEAD = (short)0x0012;
    // Maximum response handler capacity to be used for the receive data 
    private static short myRspHdlrCapacity;
    
    // Port number : integer
    private static byte[] portNumber = {(byte)0x00,(byte)0x23};
    // Channel Identifier given by the ME after the OPEN CHANNEL proactive command
    private static byte channelID = 0x00;
    // Byte array where data from the ME buffer is stored
    private static byte[] channelData = new byte [BUFFER_SIZE];
    // IP Address of the Server 
    private static byte[] IPAddress = {(byte)163,(byte)187,(byte)203,(byte)1};

    /**
    * Constructor of the applet
    */
    public MyToolkitApplet() {

        // get the GSM application reference
        gsmFile = SIMSystem.getTheSIMView();

        // register to the SIM Toolkit Framework
        reg = ToolkitRegistry.getEntry();

        // Define the applet Menu Entry and register to the EVENT_MENU_SELECTION
        itemId = reg.initMenuEntry(menuEntry, (short)0x0000, (short)menuEntry.length, 
                                   PRO_CMD_DISPLAY_TEXT, false, (byte) 0x00, (short) 0x0000);

        // register to the EVENT_UNFORMATTED_SMS_PP_ENV
        reg.setEvent(EVENT_UNFORMATTED_SMS_PP_ENV);
        
        // register to the EVENT_EVENT_DOWNLOAD_DATA_AVAILABLE
        reg.setEvent(EVENT_EVENT_DOWNLOAD_DATA_AVAILABLE);
    }

    /**
    * Method called by the JCRE at the installation of the applet
    */
    public static void install(byte bArray[], short bOffset, byte bLength) {
        MyToolkitApplet MyApplet = new MyToolkitApplet();
        MyApplet.register();
    }

    /**
    * Method called by the GSM Framework
    */
    public Shareable getShareableInterfaceObject(AID clientAID, byte parameter){
        if (parameter == (byte) 0x00){
            if ( clientAID.partialEquals(baGSMAID, (byte) 0x00, (byte) baGSMAID.length) == true )
                return((Shareable) this);
        }
        return(null);
    }

    /**
    * Method called by the SIM Toolkit Framework
    */
    public void processToolkit(byte event) {

        // get the handler references
        EnvelopeHandler          envHdlr = EnvelopeHandler.getTheHandler();
        ProactiveHandler         proHdlr = ProactiveHandler.getTheHandler();
        ProactiveResponseHandler rspHdlr ;
        boolean repeat;

        switch(event) {

            case EVENT_MENU_SELECTION:
                // Prepare the Select Item proactive command
                proHdlr.init(PRO_CMD_SELECT_ITEM,(byte)0x00,DEV_ID_ME);
                // Append the Menu Title
                proHdlr.appendTLV((byte) (TAG_ALPHA_IDENTIFIER | TAG_SET_CR),
                                 menuTitle,(short)0x0000,(short)menuTitle.length);
                // add all the Item
                for (short i=(short) 0x0000; i<(short) 0x0004; i++) {
                    proHdlr.appendTLV((byte) (TAG_ITEM | TAG_SET_CR),(byte) (i+1),
                                      (byte[])ItemList[i],(short) 0x0000,
                                      (short)((byte[])ItemList[i]).length);
                }
                // ask the SIM Toolkit Framework to send the proactive command and check the result
                if((result = proHdlr.send()) == RES_CMD_PERF){
                    rspHdlr = ProactiveResponseHandler.getTheHandler();

                    // SelectItem response handling
                    switch (rspHdlr.getItemIdentifier()) {
                        case 1:
                        case 2:
                        
                            // 1� Open GPRS connection
                            // Prepare the Open Channel(on demand link establishment = 0x00 for the qualifier byte)
                            proHdlr.init(PRO_CMD_OPEN_CHANNEL,(byte)0x00, DEV_ID_ME);
                            // Add Bearer description TLV
                            proHdlr.appendTLV((byte)(TAG_BEARER_DESCRIPTION | TAG_SET_CR),(byte)BEARER_TYPE_GPRS,
                                                BearerParameters, (short)0x0000, (short)BearerParameters.length);
                            // Add Buffer size TLV
                            proHdlr.appendTLV((byte)(TAG_BUFFER_SIZE | TAG_SET_CR),(byte)(BUFFER_SIZE>>(byte)8),(byte)BUFFER_SIZE);
                            // Add APN TLV
                            proHdlr.appendTLV((byte)(TAG_NETWORK_ACCESS_NAME | TAG_SET_CR),myAPN,(short)0,(short)myAPN.length);
                            // Add SIM/ME interface transport level UDP=01, Port 23 = Telnet
                            proHdlr.appendTLV((byte) (TAG_SIM_ME_INTERFACE_TRANSPORT_LEVEL | TAG_SET_CR),TRANSPORT_PROTOCOL_TYPE, 
                                                portNumber, (short)0, (short)portNumber.length);
                            // Add Data Destination Address TLV
                            // Type of Address IPV4=21, IPAddress contains the IPV4 Address
                            proHdlr.appendTLV((byte) (TAG_DATA_DESTINATION_ADDRESS | TAG_SET_CR),TYPE_OF_ADDRESS_IPV4, 
                                                IPAddress,(short)0, (short) IPAddress.length);

                            result = proHdlr.send();

                            // 2� Retrieve the channel ID allocated by the ME 
                            if (result == RES_CMD_PERF){
                                rspHdlr = ProactiveResponseHandler.getTheHandler();
                                channelID = rspHdlr.getChannelIdentifier();
                                // Get the maximum size of the Simple TLV list managed by the response handler
                                myRspHdlrCapacity = rspHdlr.getCapacity();
                    
                            }
                            else {
                                channelID = 0x00;
                            }

                        break;

                        case 3: 
                            // DisplayText High Priority 
                            proHdlr.init(PRO_CMD_DISPLAY_TEXT, CMD_QUALIFIER,DEV_ID_DISPLAY);
                            proHdlr.appendTLV((byte)(TAG_TEXT_STRING| TAG_SET_CR), DCS_8_BIT_DATA,
                                                textDText,(short)0x0000, (short)textDText.length);
                            proHdlr.send();
                        break;

                        case 4: // Ask the user to enter data and display it
                            do {
                                repeat = false;
                                try {
                                    // GetInput asking the users name
                                    proHdlr.initGetInput((byte)0x01, DCS_8_BIT_DATA, textGInput,(byte)0x00,
                                                (short)textGInput.length,(short)0x0001,(short)0x0002);
                                    proHdlr.send();
                                    // Display the entered text
                                    rspHdlr.copyTextString(textDText,(short)0x0000);
                                    proHdlr.initDisplayText((byte)0x00,DCS_8_BIT_DATA, textDText,
                                                            (short)0x0000,(short) textDText.length);
                                    proHdlr.send();
                                }
                                catch (ToolkitException MyException) {
                                    if (MyException.getReason() == ToolkitException.UNAVAILABLE_ELEMENT ){
                                        if (rspHdlr.getGeneralResult() != EXIT_REQUESTED_BY_USER)
                                            repeat = true;
                                        break;
                                    }
                                }
                            }
                            while(repeat);
                        break;
                    }
                }
            break;

            case EVENT_UNFORMATTED_SMS_PP_ENV:
                // get the offset of the instruction in the TP-UD field 
                short TPUDOffset = (short) (envHdlr.getTPUDLOffset() + SERVER_OPERATION);

                // start the action requested by the server 
                switch (envHdlr.getValueByte((short)TPUDOffset) ) {
                    case 0x41 : // Update of a gsm file
                        // get the data from the received SMS
                        envHdlr.copyValue((short)(TPUDOffset+1),buffer,(short)0x0000,(short)0x0003);
                        // write these data in the EFpuct
                        gsmFile.select(SIMView.FID_DF_GSM);
                        gsmFile.select(SIMView.FID_EF_PUCT);
                        gsmFile.updateBinary((short)0x0000,buffer,(short)0x0000,(short)0x0003);
                    break;

                    case 0x36 : // change the MenuTitle for the SelectItem
                        envHdlr.copyValue((short)(TPUDOffset+1), menuTitle,(short)0x0000,(short)0x0006);
                    break;
                }
            break;
                
            case EVENT_EVENT_DOWNLOAD_DATA_AVAILABLE:

                // 1� Verify the channel ID (in case this applet uses several of them )
                if ( channelID == envHdlr.getChannelIdentifier()) {
                    // Amount of data available in the ME Buffer ( FF, means more than 255 bytes)
                    byte channelDataRemainingLgth;
                    // Offset in the data array where data from the ME buffer is stored
                    short channelDataOffset = 0;

                    envHdlr.findTLV(TAG_CHANNEL_DATA_LENGTH ,(byte)0x01);
                    channelDataRemainingLgth = envHdlr.getValueByte((short)0x0000);
                                                    
                    do {
                        
                        // Maximize the size of data to retrieve by myMaxChannelDataSize
                        if ( (short)(myRspHdlrCapacity - MAX_TLV_OVERHEAD) < (short)(( (short)(channelDataRemainingLgth) & (short)0x00FF))) {
                            channelDataRemainingLgth = (byte)((short)(myRspHdlrCapacity - MAX_TLV_OVERHEAD));
                        }
                            
                        // 2� Receive the available data in the ME buffer
                        proHdlr.init(PRO_CMD_RECEIVE_DATA,(byte)0,channelID);
                        proHdlr.appendTLV((byte)(TAG_CHANNEL_DATA_LENGTH | TAG_SET_CR),channelDataRemainingLgth);
                        result = proHdlr.send();

                        // 3� Store the received data in the "channelData" array for later treatment
                        if ( result == RES_CMD_PERF ) {
                            rspHdlr = ProactiveResponseHandler.getTheHandler();
                            rspHdlr.findTLV(TAG_CHANNEL_DATA,(byte)0x01);
                            channelDataOffset = rspHdlr.copyChannelData(channelData,channelDataOffset, rspHdlr.getValueLength() );
                            
                            // Get the remaining available number of bytes in the ME reception buffer
                            rspHdlr.findTLV(TAG_CHANNEL_DATA_LENGTH ,(byte)0x01);
                            channelDataRemainingLgth = rspHdlr.getValueByte((short)0x0000);
                            
                        }

                    } while( channelDataRemainingLgth != (byte)0);

                    /* All data has been received, we can close the channel */
                    proHdlr.initCloseChannel(channelID);
                    proHdlr.send();

                    // Process the data received in channelData
                    //.....
                    //....
                }

            break;

        }
    }

    /**
    * Method called by the JCRE, once selected
    */
    public void process(APDU apdu) {
        // Handle the Select AID apdu
        if(selectingApplet())
            return;

        switch(apdu.getBuffer()[1]) {
            // specific APDU for this applet to configure the MenuTitle from SelectItem
            case (byte)MY_INSTRUCTION:
                if(apdu.setIncomingAndReceive() > (short)0) {
                    Util.arrayCopy(apdu.getBuffer(),(short)0x0005,menuTitle,(short)0x0000,(short)0x0006);
                }
            break;

            default:
                ISOException.throwIt(ISO7816.SW_INS_NOT_SUPPORTED);
        }
    }
}

